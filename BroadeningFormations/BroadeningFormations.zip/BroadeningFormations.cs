#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BroadeningFormations[] cacheBroadeningFormations;

		
		public BroadeningFormations BroadeningFormations(int period, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle, bool keepOnlyRecent)
		{
			return BroadeningFormations(Input, period, buyClr, sellClr, iWdth, eStyle, keepOnlyRecent);
		}


		
		public BroadeningFormations BroadeningFormations(ISeries<double> input, int period, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle, bool keepOnlyRecent)
		{
			if (cacheBroadeningFormations != null)
				for (int idx = 0; idx < cacheBroadeningFormations.Length; idx++)
					if (cacheBroadeningFormations[idx].Period == period && cacheBroadeningFormations[idx].BuyClr == buyClr && cacheBroadeningFormations[idx].SellClr == sellClr && cacheBroadeningFormations[idx].iWdth == iWdth && cacheBroadeningFormations[idx].eStyle == eStyle && cacheBroadeningFormations[idx].KeepOnlyRecent == keepOnlyRecent && cacheBroadeningFormations[idx].EqualsInput(input))
						return cacheBroadeningFormations[idx];
			return CacheIndicator<BroadeningFormations>(new BroadeningFormations(){ Period = period, BuyClr = buyClr, SellClr = sellClr, iWdth = iWdth, eStyle = eStyle, KeepOnlyRecent = keepOnlyRecent }, input, ref cacheBroadeningFormations);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BroadeningFormations BroadeningFormations(int period, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle, bool keepOnlyRecent)
		{
			return indicator.BroadeningFormations(Input, period, buyClr, sellClr, iWdth, eStyle, keepOnlyRecent);
		}


		
		public Indicators.BroadeningFormations BroadeningFormations(ISeries<double> input , int period, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle, bool keepOnlyRecent)
		{
			return indicator.BroadeningFormations(input, period, buyClr, sellClr, iWdth, eStyle, keepOnlyRecent);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BroadeningFormations BroadeningFormations(int period, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle, bool keepOnlyRecent)
		{
			return indicator.BroadeningFormations(Input, period, buyClr, sellClr, iWdth, eStyle, keepOnlyRecent);
		}


		
		public Indicators.BroadeningFormations BroadeningFormations(ISeries<double> input , int period, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle, bool keepOnlyRecent)
		{
			return indicator.BroadeningFormations(input, period, buyClr, sellClr, iWdth, eStyle, keepOnlyRecent);
		}

	}
}

#endregion
