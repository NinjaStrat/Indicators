#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private StratEngineSniperIndicator[] cacheStratEngineSniperIndicator;

		
		public StratEngineSniperIndicator StratEngineSniperIndicator(bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, int inForceHTF, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return StratEngineSniperIndicator(Input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, inForceHTF, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public StratEngineSniperIndicator StratEngineSniperIndicator(ISeries<double> input, bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, int inForceHTF, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			if (cacheStratEngineSniperIndicator != null)
				for (int idx = 0; idx < cacheStratEngineSniperIndicator.Length; idx++)
					if (cacheStratEngineSniperIndicator[idx].ShowArrows == showArrows && cacheStratEngineSniperIndicator[idx].ShowBackgroundColor == showBackgroundColor && cacheStratEngineSniperIndicator[idx].ShowBarColor == showBarColor && cacheStratEngineSniperIndicator[idx].MinimumAlignedTimeframes == minimumAlignedTimeframes && cacheStratEngineSniperIndicator[idx].RequireLtfConfirmation == requireLtfConfirmation && cacheStratEngineSniperIndicator[idx].StartTime == startTime && cacheStratEngineSniperIndicator[idx].EndTime == endTime && cacheStratEngineSniperIndicator[idx].HTF1 == hTF1 && cacheStratEngineSniperIndicator[idx].HTF2 == hTF2 && cacheStratEngineSniperIndicator[idx].HTF3 == hTF3 && cacheStratEngineSniperIndicator[idx].InForceHTF == inForceHTF && cacheStratEngineSniperIndicator[idx].MomoTF == momoTF && cacheStratEngineSniperIndicator[idx].LongArrowColor == longArrowColor && cacheStratEngineSniperIndicator[idx].LongBackgroundColor == longBackgroundColor && cacheStratEngineSniperIndicator[idx].LongBarColor == longBarColor && cacheStratEngineSniperIndicator[idx].ShortArrowColor == shortArrowColor && cacheStratEngineSniperIndicator[idx].ShortBackgroundColor == shortBackgroundColor && cacheStratEngineSniperIndicator[idx].ShortBarColor == shortBarColor && cacheStratEngineSniperIndicator[idx].EqualsInput(input))
						return cacheStratEngineSniperIndicator[idx];
			return CacheIndicator<StratEngineSniperIndicator>(new StratEngineSniperIndicator(){ ShowArrows = showArrows, ShowBackgroundColor = showBackgroundColor, ShowBarColor = showBarColor, MinimumAlignedTimeframes = minimumAlignedTimeframes, RequireLtfConfirmation = requireLtfConfirmation, StartTime = startTime, EndTime = endTime, HTF1 = hTF1, HTF2 = hTF2, HTF3 = hTF3, InForceHTF = inForceHTF, MomoTF = momoTF, LongArrowColor = longArrowColor, LongBackgroundColor = longBackgroundColor, LongBarColor = longBarColor, ShortArrowColor = shortArrowColor, ShortBackgroundColor = shortBackgroundColor, ShortBarColor = shortBarColor }, input, ref cacheStratEngineSniperIndicator);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.StratEngineSniperIndicator StratEngineSniperIndicator(bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, int inForceHTF, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineSniperIndicator(Input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, inForceHTF, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.StratEngineSniperIndicator StratEngineSniperIndicator(ISeries<double> input , bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, int inForceHTF, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineSniperIndicator(input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, inForceHTF, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.StratEngineSniperIndicator StratEngineSniperIndicator(bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, int inForceHTF, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineSniperIndicator(Input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, inForceHTF, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.StratEngineSniperIndicator StratEngineSniperIndicator(ISeries<double> input , bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, int inForceHTF, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineSniperIndicator(input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, inForceHTF, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}

	}
}

#endregion
