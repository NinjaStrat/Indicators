#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NinjaStrat.StratSniper[] cacheStratSniper;

		
		public NinjaStrat.StratSniper StratSniper(bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, bool includeThreeBarPatterns, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return StratSniper(Input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, includeThreeBarPatterns, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public NinjaStrat.StratSniper StratSniper(ISeries<double> input, bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, bool includeThreeBarPatterns, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			if (cacheStratSniper != null)
				for (int idx = 0; idx < cacheStratSniper.Length; idx++)
					if (cacheStratSniper[idx].ShowArrows == showArrows && cacheStratSniper[idx].ShowBackgroundColor == showBackgroundColor && cacheStratSniper[idx].ShowBarColor == showBarColor && cacheStratSniper[idx].MinimumAlignedTimeframes == minimumAlignedTimeframes && cacheStratSniper[idx].RequireLtfConfirmation == requireLtfConfirmation && cacheStratSniper[idx].StartTime == startTime && cacheStratSniper[idx].EndTime == endTime && cacheStratSniper[idx].HTF1 == hTF1 && cacheStratSniper[idx].HTF2 == hTF2 && cacheStratSniper[idx].HTF3 == hTF3 && cacheStratSniper[idx].IncludeThreeBarPatterns == includeThreeBarPatterns && cacheStratSniper[idx].MomoTF == momoTF && cacheStratSniper[idx].LongArrowColor == longArrowColor && cacheStratSniper[idx].LongBackgroundColor == longBackgroundColor && cacheStratSniper[idx].LongBarColor == longBarColor && cacheStratSniper[idx].ShortArrowColor == shortArrowColor && cacheStratSniper[idx].ShortBackgroundColor == shortBackgroundColor && cacheStratSniper[idx].ShortBarColor == shortBarColor && cacheStratSniper[idx].EqualsInput(input))
						return cacheStratSniper[idx];
			return CacheIndicator<NinjaStrat.StratSniper>(new NinjaStrat.StratSniper(){ ShowArrows = showArrows, ShowBackgroundColor = showBackgroundColor, ShowBarColor = showBarColor, MinimumAlignedTimeframes = minimumAlignedTimeframes, RequireLtfConfirmation = requireLtfConfirmation, StartTime = startTime, EndTime = endTime, HTF1 = hTF1, HTF2 = hTF2, HTF3 = hTF3, IncludeThreeBarPatterns = includeThreeBarPatterns, MomoTF = momoTF, LongArrowColor = longArrowColor, LongBackgroundColor = longBackgroundColor, LongBarColor = longBarColor, ShortArrowColor = shortArrowColor, ShortBackgroundColor = shortBackgroundColor, ShortBarColor = shortBarColor }, input, ref cacheStratSniper);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NinjaStrat.StratSniper StratSniper(bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, bool includeThreeBarPatterns, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratSniper(Input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, includeThreeBarPatterns, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.NinjaStrat.StratSniper StratSniper(ISeries<double> input , bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, bool includeThreeBarPatterns, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratSniper(input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, includeThreeBarPatterns, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NinjaStrat.StratSniper StratSniper(bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, bool includeThreeBarPatterns, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratSniper(Input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, includeThreeBarPatterns, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.NinjaStrat.StratSniper StratSniper(ISeries<double> input , bool showArrows, bool showBackgroundColor, bool showBarColor, int minimumAlignedTimeframes, bool requireLtfConfirmation, DateTime startTime, DateTime endTime, int hTF1, int hTF2, int hTF3, bool includeThreeBarPatterns, bool momoTF, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratSniper(input, showArrows, showBackgroundColor, showBarColor, minimumAlignedTimeframes, requireLtfConfirmation, startTime, endTime, hTF1, hTF2, hTF3, includeThreeBarPatterns, momoTF, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}

	}
}

#endregion
