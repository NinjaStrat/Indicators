#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NinjaStrat.Failed2s[] cacheFailed2s;

		
		public NinjaStrat.Failed2s Failed2s(int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return Failed2s(Input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public NinjaStrat.Failed2s Failed2s(ISeries<double> input, int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			if (cacheFailed2s != null)
				for (int idx = 0; idx < cacheFailed2s.Length; idx++)
					if (cacheFailed2s[idx].InForceHTF == inForceHTF && cacheFailed2s[idx].HTF1 == hTF1 && cacheFailed2s[idx].HTF2 == hTF2 && cacheFailed2s[idx].HTF3 == hTF3 && cacheFailed2s[idx].HTF4 == hTF4 && cacheFailed2s[idx].TfcTF == tfcTF && cacheFailed2s[idx].ShowArrows == showArrows && cacheFailed2s[idx].ShowBackgroundColor == showBackgroundColor && cacheFailed2s[idx].ShowBarColor == showBarColor && cacheFailed2s[idx].LongArrowColor == longArrowColor && cacheFailed2s[idx].LongBackgroundColor == longBackgroundColor && cacheFailed2s[idx].LongBarColor == longBarColor && cacheFailed2s[idx].ShortArrowColor == shortArrowColor && cacheFailed2s[idx].ShortBackgroundColor == shortBackgroundColor && cacheFailed2s[idx].ShortBarColor == shortBarColor && cacheFailed2s[idx].EqualsInput(input))
						return cacheFailed2s[idx];
			return CacheIndicator<NinjaStrat.Failed2s>(new NinjaStrat.Failed2s(){ InForceHTF = inForceHTF, HTF1 = hTF1, HTF2 = hTF2, HTF3 = hTF3, HTF4 = hTF4, TfcTF = tfcTF, ShowArrows = showArrows, ShowBackgroundColor = showBackgroundColor, ShowBarColor = showBarColor, LongArrowColor = longArrowColor, LongBackgroundColor = longBackgroundColor, LongBarColor = longBarColor, ShortArrowColor = shortArrowColor, ShortBackgroundColor = shortBackgroundColor, ShortBarColor = shortBarColor }, input, ref cacheFailed2s);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NinjaStrat.Failed2s Failed2s(int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.Failed2s(Input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.NinjaStrat.Failed2s Failed2s(ISeries<double> input , int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.Failed2s(input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NinjaStrat.Failed2s Failed2s(int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.Failed2s(Input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.NinjaStrat.Failed2s Failed2s(ISeries<double> input , int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.Failed2s(input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}

	}
}

#endregion
