#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private StratEngineFailed2sIndicator[] cacheStratEngineFailed2sIndicator;

		
		public StratEngineFailed2sIndicator StratEngineFailed2sIndicator(int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return StratEngineFailed2sIndicator(Input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public StratEngineFailed2sIndicator StratEngineFailed2sIndicator(ISeries<double> input, int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			if (cacheStratEngineFailed2sIndicator != null)
				for (int idx = 0; idx < cacheStratEngineFailed2sIndicator.Length; idx++)
					if (cacheStratEngineFailed2sIndicator[idx].InForceHTF == inForceHTF && cacheStratEngineFailed2sIndicator[idx].HTF1 == hTF1 && cacheStratEngineFailed2sIndicator[idx].HTF2 == hTF2 && cacheStratEngineFailed2sIndicator[idx].HTF3 == hTF3 && cacheStratEngineFailed2sIndicator[idx].HTF4 == hTF4 && cacheStratEngineFailed2sIndicator[idx].TfcTF == tfcTF && cacheStratEngineFailed2sIndicator[idx].ShowArrows == showArrows && cacheStratEngineFailed2sIndicator[idx].ShowBackgroundColor == showBackgroundColor && cacheStratEngineFailed2sIndicator[idx].ShowBarColor == showBarColor && cacheStratEngineFailed2sIndicator[idx].LongArrowColor == longArrowColor && cacheStratEngineFailed2sIndicator[idx].LongBackgroundColor == longBackgroundColor && cacheStratEngineFailed2sIndicator[idx].LongBarColor == longBarColor && cacheStratEngineFailed2sIndicator[idx].ShortArrowColor == shortArrowColor && cacheStratEngineFailed2sIndicator[idx].ShortBackgroundColor == shortBackgroundColor && cacheStratEngineFailed2sIndicator[idx].ShortBarColor == shortBarColor && cacheStratEngineFailed2sIndicator[idx].EqualsInput(input))
						return cacheStratEngineFailed2sIndicator[idx];
			return CacheIndicator<StratEngineFailed2sIndicator>(new StratEngineFailed2sIndicator(){ InForceHTF = inForceHTF, HTF1 = hTF1, HTF2 = hTF2, HTF3 = hTF3, HTF4 = hTF4, TfcTF = tfcTF, ShowArrows = showArrows, ShowBackgroundColor = showBackgroundColor, ShowBarColor = showBarColor, LongArrowColor = longArrowColor, LongBackgroundColor = longBackgroundColor, LongBarColor = longBarColor, ShortArrowColor = shortArrowColor, ShortBackgroundColor = shortBackgroundColor, ShortBarColor = shortBarColor }, input, ref cacheStratEngineFailed2sIndicator);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.StratEngineFailed2sIndicator StratEngineFailed2sIndicator(int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineFailed2sIndicator(Input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.StratEngineFailed2sIndicator StratEngineFailed2sIndicator(ISeries<double> input , int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineFailed2sIndicator(input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.StratEngineFailed2sIndicator StratEngineFailed2sIndicator(int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineFailed2sIndicator(Input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}


		
		public Indicators.StratEngineFailed2sIndicator StratEngineFailed2sIndicator(ISeries<double> input , int inForceHTF, int hTF1, int hTF2, int hTF3, int hTF4, bool tfcTF, bool showArrows, bool showBackgroundColor, bool showBarColor, Brush longArrowColor, Brush longBackgroundColor, Brush longBarColor, Brush shortArrowColor, Brush shortBackgroundColor, Brush shortBarColor)
		{
			return indicator.StratEngineFailed2sIndicator(input, inForceHTF, hTF1, hTF2, hTF3, hTF4, tfcTF, showArrows, showBackgroundColor, showBarColor, longArrowColor, longBackgroundColor, longBarColor, shortArrowColor, shortBackgroundColor, shortBarColor);
		}

	}
}

#endregion
